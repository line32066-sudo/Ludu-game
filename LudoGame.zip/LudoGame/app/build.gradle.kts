plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    // CHANGE THIS to your own package name before publishing (e.g. "com.yourname.ludo").
    // If you change it, also move the Kotlin package folders and update the package lines.
    namespace = "com.example.ludogame"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.ludogame"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Google AdMob (Google Mobile Ads SDK)
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
