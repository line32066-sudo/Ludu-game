# Add project specific ProGuard rules here.
# The Google Mobile Ads SDK ships its own consumer rules, so nothing extra is required.
