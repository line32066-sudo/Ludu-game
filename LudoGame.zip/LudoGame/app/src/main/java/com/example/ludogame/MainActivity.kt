package com.example.ludogame

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ludogame.ads.AdManager
import com.example.ludogame.ads.BannerStyle
import com.example.ludogame.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Banner ad at the bottom of the menu.
        AdManager.attachBanner(this, binding.bannerContainer, BannerStyle.LARGE_ADAPTIVE)

        binding.startButton.setOnClickListener {
            val players = when (binding.playersGroup.checkedRadioButtonId) {
                R.id.rb2 -> 2
                R.id.rb3 -> 3
                else -> 4
            }
            val intent = Intent(this, GameActivity::class.java)
                .putExtra(GameActivity.EXTRA_PLAYERS, players)
                .putExtra(GameActivity.EXTRA_VS_COMPUTER, binding.switchBots.isChecked)
            startActivity(intent)
        }
    }
}
