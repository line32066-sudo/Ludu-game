package com.example.ludogame

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.ludogame.ads.AdManager
import com.example.ludogame.ads.BannerStyle
import com.example.ludogame.databinding.ActivityGameBinding
import com.example.ludogame.game.GameEngine
import com.example.ludogame.game.LudoPlayer
import com.example.ludogame.game.Phase
import com.example.ludogame.game.PlayerColor
import com.example.ludogame.game.RollOutcome
import com.example.ludogame.game.Token

class GameActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PLAYERS = "extra_players"
        const val EXTRA_VS_COMPUTER = "extra_vs_computer"
    }

    private lateinit var binding: ActivityGameBinding
    private lateinit var engine: GameEngine

    private val handler = Handler(Looper.getMainLooper())
    private val chips = mutableListOf<TextView>()

    private var playerCount = 4
    private var vsComputer = true

    /** True while something is animating or the computer is thinking: input is ignored. */
    private var busy = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerCount = intent.getIntExtra(EXTRA_PLAYERS, 4).coerceIn(2, 4)
        vsComputer = intent.getBooleanExtra(EXTRA_VS_COMPUTER, true)

        // Banner ad at the bottom of the game screen (compact, to leave room for the board).
        AdManager.attachBanner(this, binding.bannerContainer, BannerStyle.COMPACT)

        binding.diceView.setOnClickListener { onDiceClicked() }
        binding.boardView.onTokenTapped = { token -> onTokenTapped(token) }
        binding.rewardButton.setOnClickListener { onRewardClicked() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                confirmQuit()
            }
        })

        startNewMatch()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun alive(): Boolean = !isFinishing && !isDestroyed

    // ------------------------------------------------------------------ match setup

    private fun createEngine(): GameEngine {
        val colors = when (playerCount) {
            2 -> listOf(PlayerColor.RED, PlayerColor.YELLOW)
            3 -> listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW)
            else -> PlayerColor.values().toList()
        }
        // The first seat is always a human; the other seats are bots when "play vs computer" is on.
        return GameEngine(colors.mapIndexed { i, c -> LudoPlayer(c, isBot = vsComputer && i != 0) })
    }

    private fun startNewMatch() {
        handler.removeCallbacksAndMessages(null)
        engine = createEngine()
        binding.boardView.engine = engine
        binding.boardView.highlighted = emptyList()
        binding.diceView.value = 1
        buildChips()
        startTurn()
    }

    // ------------------------------------------------------------------ turn flow

    private fun startTurn() {
        refreshHeader()
        val player = engine.current
        if (player.isBot) {
            busy = true
            binding.statusText.text = getString(R.string.status_bot_thinking, player.name)
            handler.postDelayed({ if (alive()) rollDice() }, 800)
        } else {
            busy = false
            binding.statusText.text = getString(R.string.status_tap_dice)
        }
        updateRewardButton()
    }

    private fun onDiceClicked() {
        if (busy || engine.phase != Phase.ROLL || engine.current.isBot) return
        rollDice()
    }

    private fun rollDice() {
        busy = true
        updateRewardButton()
        binding.statusText.text = getString(R.string.status_rolling)

        val outcome = engine.roll()
        val value = engine.diceValue

        binding.diceView.roll(value) {
            if (!alive()) return@roll
            when (outcome) {
                RollOutcome.THREE_SIXES -> {
                    binding.statusText.text = getString(R.string.status_three_sixes)
                    handler.postDelayed({
                        if (alive()) {
                            engine.forfeitTurn()
                            startTurn()
                        }
                    }, 1200)
                }
                RollOutcome.NO_MOVES -> {
                    binding.statusText.text = getString(R.string.status_no_moves, value)
                    handler.postDelayed({
                        if (alive()) {
                            engine.skipTurn()
                            startTurn()
                        }
                    }, 1000)
                }
                RollOutcome.CAN_MOVE -> handleMovePhase()
            }
        }
    }

    private fun handleMovePhase() {
        val movable = engine.movableTokens()
        when {
            engine.current.isBot ->
                handler.postDelayed({ if (alive()) moveToken(engine.chooseBotToken()) }, 600)

            // One legal move, or all legal moves are identical (e.g. four tokens in the base): do it for the player.
            movable.map { it.progress }.distinct().size == 1 ->
                handler.postDelayed({ if (alive()) moveToken(movable.first()) }, 350)

            else -> {
                busy = false
                binding.boardView.highlighted = movable
                binding.statusText.text = getString(R.string.status_tap_token, engine.diceValue)
            }
        }
    }

    private fun onTokenTapped(token: Token) {
        if (busy || !engine.canMove(token)) return
        moveToken(token)
    }

    private fun moveToken(token: Token) {
        busy = true
        binding.boardView.highlighted = emptyList()
        val path = engine.pathFor(token)
        binding.boardView.animateMove(token, path) {
            if (!alive()) return@animateMove
            val result = engine.applyMove(token)
            binding.boardView.invalidate()
            if (result.captured.isNotEmpty()) {
                Toast.makeText(this, R.string.captured_message, Toast.LENGTH_SHORT).show()
            }
            if (result.won) {
                onGameOver(engine.winner ?: engine.current)
            } else {
                startTurn()
            }
        }
    }

    // ------------------------------------------------------------------ rewarded video (optional bonus)

    private fun updateRewardButton() {
        val enabled = !busy && engine.phase == Phase.ROLL && !engine.current.isBot
        binding.rewardButton.isEnabled = enabled
        binding.rewardButton.alpha = if (enabled) 1f else 0.45f
    }

    private fun onRewardClicked() {
        if (busy || engine.phase != Phase.ROLL || engine.current.isBot) return
        val shown = AdManager.showRewarded(this) { earned ->
            if (earned && alive() && engine.phase == Phase.ROLL && !engine.current.isBot) {
                engine.grantLuckySix(engine.current.color)
                Toast.makeText(this, R.string.reward_earned, Toast.LENGTH_LONG).show()
            }
        }
        if (!shown) {
            Toast.makeText(this, R.string.reward_not_ready, Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ end of match

    private fun onGameOver(winner: LudoPlayer) {
        busy = true
        refreshHeader()
        updateRewardButton()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.win_title, winner.name))
            .setMessage(R.string.win_message)
            .setCancelable(false)
            .setPositiveButton(R.string.win_play_again) { _, _ ->
                // Interstitial ad after every finished match, then the next match starts.
                AdManager.showInterstitial(this) {
                    if (alive()) startNewMatch()
                }
            }
            .setNegativeButton(R.string.win_menu) { _, _ ->
                AdManager.showInterstitial(this) {
                    if (alive()) finish()
                }
            }
            .show()
    }

    private fun confirmQuit() {
        AlertDialog.Builder(this)
            .setTitle(R.string.quit_title)
            .setMessage(R.string.quit_message)
            .setPositiveButton(R.string.quit_yes) { _, _ -> finish() }
            .setNegativeButton(R.string.quit_no, null)
            .show()
    }

    // ------------------------------------------------------------------ header / player chips

    private fun buildChips() {
        binding.playersContainer.removeAllViews()
        chips.clear()
        for (player in engine.players) {
            val chip = TextView(this).apply {
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setTextColor(if (player.color == PlayerColor.YELLOW) 0xDE000000.toInt() else Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(player.color.main)
                }
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
            binding.playersContainer.addView(chip, params)
            chips.add(chip)
        }
    }

    private fun refreshHeader() {
        val player = engine.current
        val botMark = if (player.isBot) " 🤖" else ""
        binding.turnText.text = getString(R.string.turn_format, player.name + botMark)
        binding.turnText.setTextColor(player.color.dark)

        engine.players.forEachIndexed { i, p ->
            val mark = if (p.isBot) " 🤖" else ""
            chips[i].text = "${p.name}$mark ${p.finishedCount}/4"
            chips[i].alpha = if (p === player) 1f else 0.5f
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
