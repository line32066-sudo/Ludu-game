package com.example.ludogame.game

import kotlin.random.Random

/** One pawn. See [Board] for the meaning of [progress]. */
class Token(val color: PlayerColor, val index: Int) {
    var progress: Int = -1
    val inBase: Boolean get() = progress == -1
    val finished: Boolean get() = progress == Board.FINISH
}

class LudoPlayer(val color: PlayerColor, val isBot: Boolean) {
    val tokens: List<Token> = List(4) { Token(color, it) }
    val name: String get() = color.label
    val finishedCount: Int get() = tokens.count { it.finished }
}

enum class Phase { ROLL, MOVE, OVER }

enum class RollOutcome { CAN_MOVE, NO_MOVES, THREE_SIXES }

data class MoveResult(
    val captured: List<Token>,
    val reachedHome: Boolean,
    val extraTurn: Boolean,
    val won: Boolean
)

/**
 * Pure game rules, with no Android code in it.
 *
 * Rules implemented:
 *  - A 6 is needed to bring a token out of the base.
 *  - Rolling a 6, capturing a token or reaching home gives another turn.
 *  - Three sixes in a row forfeit the turn.
 *  - Landing on an opponent captures it (it goes back to its base), except on safe squares.
 *  - A token must reach the centre with an exact roll.
 *  - The first player to bring all four tokens home wins the match.
 */
class GameEngine(
    val players: List<LudoPlayer>,
    private val random: Random = Random.Default
) {
    init {
        require(players.size in 2..4) { "Ludo needs 2 to 4 players" }
    }

    var currentIndex: Int = 0
        private set

    var diceValue: Int = 0
        private set

    var phase: Phase = Phase.ROLL
        private set

    var winner: LudoPlayer? = null
        private set

    private var consecutiveSixes = 0
    private var luckySixFor: PlayerColor? = null

    val current: LudoPlayer get() = players[currentIndex]

    /** Rewarded-ad bonus: the given player's next roll will be a 6. */
    fun grantLuckySix(color: PlayerColor) {
        luckySixFor = color
    }

    fun roll(): RollOutcome {
        check(phase == Phase.ROLL) { "Not in the roll phase" }
        val forced = luckySixFor == current.color
        if (forced) luckySixFor = null
        diceValue = if (forced) 6 else random.nextInt(1, 7)
        consecutiveSixes = if (diceValue == 6) consecutiveSixes + 1 else 0
        phase = Phase.MOVE
        return when {
            consecutiveSixes >= 3 -> RollOutcome.THREE_SIXES
            movableTokens().isEmpty() -> RollOutcome.NO_MOVES
            else -> RollOutcome.CAN_MOVE
        }
    }

    fun canMove(token: Token): Boolean {
        if (phase != Phase.MOVE || token.color != current.color) return false
        return when {
            token.finished -> false
            token.inBase -> diceValue == 6
            else -> token.progress + diceValue <= Board.FINISH
        }
    }

    fun movableTokens(): List<Token> = current.tokens.filter { canMove(it) }

    /** Positions the token will pass through (one per cell) so the UI can animate it. Call before [applyMove]. */
    fun pathFor(token: Token): List<Pos> {
        if (token.inBase) return listOf(Board.position(token.color, token.index, 0))
        return (1..diceValue).map { step ->
            Board.position(token.color, token.index, token.progress + step)
        }
    }

    fun applyMove(token: Token): MoveResult {
        require(canMove(token)) { "Illegal move" }
        token.progress = if (token.inBase) 0 else token.progress + diceValue

        val captured = mutableListOf<Token>()
        val abs = Board.absIndex(token.color, token.progress)
        if (abs >= 0 && abs !in Board.SAFE_INDEXES) {
            for (player in players) {
                if (player.color == token.color) continue
                for (other in player.tokens) {
                    if (Board.absIndex(other.color, other.progress) == abs) {
                        other.progress = -1
                        captured += other
                    }
                }
            }
        }

        val reachedHome = token.finished
        val extraTurn = diceValue == 6 || captured.isNotEmpty() || reachedHome
        val won = current.tokens.all { it.finished }
        if (won) {
            winner = current
            phase = Phase.OVER
        } else {
            endTurn(extraTurn)
        }
        return MoveResult(captured, reachedHome, extraTurn, won)
    }

    /** Called when the roll gave no legal move. A 6 still earns another roll. */
    fun skipTurn() = endTurn(diceValue == 6)

    /** Called after three sixes in a row. */
    fun forfeitTurn() = endTurn(false)

    private fun endTurn(extraTurn: Boolean) {
        if (phase == Phase.OVER) return
        if (!extraTurn) {
            consecutiveSixes = 0
            currentIndex = (currentIndex + 1) % players.size
        }
        phase = Phase.ROLL
    }

    // ------------------------------------------------------------------ computer player

    /** Simple AI: prefers finishing, capturing, leaving the base and landing on safe squares. */
    fun chooseBotToken(): Token {
        val options = movableTokens()
        return options.maxByOrNull { scoreMove(it) + random.nextFloat() } ?: options.first()
    }

    private fun scoreMove(token: Token): Float {
        val newProgress = if (token.inBase) 0 else token.progress + diceValue
        var score = newProgress.toFloat()
        if (newProgress == Board.FINISH) score += 100f
        if (token.inBase) score += 40f
        if (newProgress > Board.LAST_TRACK_STEP && newProgress < Board.FINISH) score += 15f

        val abs = Board.absIndex(token.color, newProgress)
        if (abs >= 0) {
            if (abs in Board.SAFE_INDEXES) {
                score += 15f
            } else {
                val victims = players
                    .filter { it.color != token.color }
                    .flatMap { it.tokens }
                    .count { Board.absIndex(it.color, it.progress) == abs }
                if (victims > 0) score += 80f + victims * 10f
            }
        }
        return score
    }
}
