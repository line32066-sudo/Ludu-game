package com.example.ludogame.game

/**
 * The four seats of a Ludo board, in clockwise turn order (RED, GREEN, YELLOW, BLUE).
 *
 * @param startIndex index of the player's start square on the 52-square main track
 * @param baseCol    column (0..14) of the top-left corner of the player's 6x6 base
 * @param baseRow    row (0..14) of the top-left corner of the player's 6x6 base
 */
enum class PlayerColor(
    val label: String,
    val startIndex: Int,
    val baseCol: Int,
    val baseRow: Int,
    val main: Int,
    val dark: Int,
    val light: Int
) {
    RED("Red", 0, 0, 0, 0xFFE53935.toInt(), 0xFFB71C1C.toInt(), 0xFFFFCDD2.toInt()),
    GREEN("Green", 13, 9, 0, 0xFF43A047.toInt(), 0xFF1B5E20.toInt(), 0xFFC8E6C9.toInt()),
    YELLOW("Yellow", 26, 9, 9, 0xFFFDD835.toInt(), 0xFFF9A825.toInt(), 0xFFFFF9C4.toInt()),
    BLUE("Blue", 39, 0, 9, 0xFF1E88E5.toInt(), 0xFF0D47A1.toInt(), 0xFFBBDEFB.toInt())
}
