package com.example.ludogame.game

/** A point on the board measured in grid cells. A cell (col,row) has its centre at (col+0.5, row+0.5). */
data class Pos(val x: Float, val y: Float)

/**
 * Geometry of the 15x15 Ludo board.
 *
 * Token "progress" values:
 *   -1      token is in its base
 *   0..50   token is on the shared 52-square track (0 = the player's own start square)
 *   51..55  token is in its coloured home column
 *   56      token has reached the centre (finished)
 */
object Board {
    const val GRID = 15
    const val TRACK_SIZE = 52
    const val LAST_TRACK_STEP = 50
    const val FINISH = 56
    private const val HOME_COLUMN_START = 51

    /** The shared track, clockwise, as (col,row). Index 0 is Red's start square. */
    val TRACK: List<Pair<Int, Int>> = listOf(
        // Red's start, going right along row 6
        1 to 6, 2 to 6, 3 to 6, 4 to 6, 5 to 6,            // 0..4
        // up column 6
        6 to 5, 6 to 4, 6 to 3, 6 to 2, 6 to 1, 6 to 0,    // 5..10
        // across the top
        7 to 0, 8 to 0,                                    // 11..12
        // down column 8 (index 13 = Green's start)
        8 to 1, 8 to 2, 8 to 3, 8 to 4, 8 to 5,            // 13..17
        // right along row 6
        9 to 6, 10 to 6, 11 to 6, 12 to 6, 13 to 6, 14 to 6, // 18..23
        // down the right edge
        14 to 7, 14 to 8,                                  // 24..25
        // left along row 8 (index 26 = Yellow's start)
        13 to 8, 12 to 8, 11 to 8, 10 to 8, 9 to 8,        // 26..30
        // down column 8
        8 to 9, 8 to 10, 8 to 11, 8 to 12, 8 to 13, 8 to 14, // 31..36
        // across the bottom
        7 to 14, 6 to 14,                                  // 37..38
        // up column 6 (index 39 = Blue's start)
        6 to 13, 6 to 12, 6 to 11, 6 to 10, 6 to 9,        // 39..43
        // left along row 8
        5 to 8, 4 to 8, 3 to 8, 2 to 8, 1 to 8, 0 to 8,    // 44..49
        // up the left edge
        0 to 7, 0 to 6                                     // 50..51
    )

    /** Squares where tokens cannot be captured: the four start squares and the four star squares. */
    val SAFE_INDEXES: Set<Int> = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    private val HOME_COLUMNS: Map<PlayerColor, List<Pair<Int, Int>>> = mapOf(
        PlayerColor.RED to listOf(1 to 7, 2 to 7, 3 to 7, 4 to 7, 5 to 7),
        PlayerColor.GREEN to listOf(7 to 1, 7 to 2, 7 to 3, 7 to 4, 7 to 5),
        PlayerColor.YELLOW to listOf(13 to 7, 12 to 7, 11 to 7, 10 to 7, 9 to 7),
        PlayerColor.BLUE to listOf(7 to 13, 7 to 12, 7 to 11, 7 to 10, 7 to 9)
    )

    fun homeColumn(color: PlayerColor): List<Pair<Int, Int>> = HOME_COLUMNS.getValue(color)

    /** Index on the shared track for a token, or -1 if it is not on the shared track. */
    fun absIndex(color: PlayerColor, progress: Int): Int =
        if (progress in 0..LAST_TRACK_STEP) (color.startIndex + progress) % TRACK_SIZE else -1

    /** Centre of one of the four parking spots inside a base. */
    fun basePos(color: PlayerColor, tokenIndex: Int): Pos {
        val dx = if (tokenIndex % 2 == 0) 2f else 4f
        val dy = if (tokenIndex < 2) 2f else 4f
        return Pos(color.baseCol + dx, color.baseRow + dy)
    }

    /** Where finished tokens are parked, next to the triangle of their colour. */
    private fun finishPos(color: PlayerColor, tokenIndex: Int): Pos {
        val shift = (tokenIndex - 1.5f) * 0.18f
        return when (color) {
            PlayerColor.RED -> Pos(6.75f, 7.5f + shift)
            PlayerColor.GREEN -> Pos(7.5f + shift, 6.75f)
            PlayerColor.YELLOW -> Pos(8.25f, 7.5f + shift)
            PlayerColor.BLUE -> Pos(7.5f + shift, 8.25f)
        }
    }

    fun position(color: PlayerColor, tokenIndex: Int, progress: Int): Pos = when {
        progress < 0 -> basePos(color, tokenIndex)
        progress <= LAST_TRACK_STEP -> {
            val cell = TRACK[(color.startIndex + progress) % TRACK_SIZE]
            Pos(cell.first + 0.5f, cell.second + 0.5f)
        }
        progress < FINISH -> {
            val cell = homeColumn(color)[progress - HOME_COLUMN_START]
            Pos(cell.first + 0.5f, cell.second + 0.5f)
        }
        else -> finishPos(color, tokenIndex)
    }
}
