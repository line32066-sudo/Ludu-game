package com.example.ludogame

import android.app.Application
import com.example.ludogame.ads.AdManager

class LudoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Starts the Google Mobile Ads SDK and preloads the interstitial and rewarded ads.
        AdManager.initialize(this)
    }
}
