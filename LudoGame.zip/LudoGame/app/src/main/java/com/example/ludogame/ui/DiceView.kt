package com.example.ludogame.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** A dice drawn with Canvas. [roll] plays a tumbling animation (spin + bounces + changing faces). */
class DiceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF455A64.toInt()
        style = Paint.Style.STROKE
    }
    private val pipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF212121.toInt() }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 }
    private val rect = RectF()

    private var spin = 0f
    private var hop = 0f
    private var animator: ValueAnimator? = null

    /** Face currently shown, 1..6. */
    var value: Int = 1
        set(newValue) {
            field = newValue.coerceIn(1, 6)
            invalidate()
        }

    /**
     * Rolls the dice. The final face is decided by the game engine ([finalValue]); this view only animates.
     * [onEnd] is called when the animation finishes (not when it is cancelled).
     */
    fun roll(finalValue: Int, durationMs: Long = 850L, onEnd: () -> Unit) {
        animator?.cancel()
        var lastStep = -1
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = durationMs
        anim.interpolator = DecelerateInterpolator(1.2f)
        anim.addUpdateListener { a ->
            val t = a.animatedFraction
            spin = 720f * t
            hop = abs(sin(PI * t * 3.0)).toFloat() * (1f - t)
            val step = (t * 14f).toInt()
            if (step != lastStep) {
                lastStep = step
                value = Random.nextInt(1, 7)
            }
            invalidate()
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false

            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                spin = 0f
                hop = 0f
                if (!cancelled) {
                    value = finalValue
                    onEnd()
                }
            }
        })
        animator = anim
        anim.start()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = min(width, height).toFloat()
        val size = side * 0.56f
        val half = size / 2f
        val cx = width / 2f
        val cy = height / 2f

        // Shadow on the "table", shrinking while the dice is in the air.
        val shadowScale = 1f - 0.35f * hop
        rect.set(
            cx - size * 0.45f * shadowScale,
            cy + size * 0.58f,
            cx + size * 0.45f * shadowScale,
            cy + size * 0.58f + size * 0.12f
        )
        canvas.drawOval(rect, shadowPaint)

        canvas.save()
        canvas.translate(cx, cy - hop * size * 0.2f)
        canvas.rotate(spin)

        rect.set(-half, -half, half, half)
        val corner = size * 0.18f
        canvas.drawRoundRect(rect, corner, corner, bodyPaint)
        edgePaint.strokeWidth = size * 0.04f
        canvas.drawRoundRect(rect, corner, corner, edgePaint)

        val pipRadius = size * 0.075f
        for (index in PIPS[value - 1]) {
            val col = index % 3
            val row = index / 3
            val px = -half + size * (0.25f + 0.25f * col)
            val py = -half + size * (0.25f + 0.25f * row)
            canvas.drawCircle(px, py, pipRadius, pipPaint)
        }
        canvas.restore()
    }

    private companion object {
        /** Pip positions on a 3x3 grid (0 = top-left ... 8 = bottom-right) for faces 1..6. */
        val PIPS: Array<IntArray> = arrayOf(
            intArrayOf(4),
            intArrayOf(0, 8),
            intArrayOf(0, 4, 8),
            intArrayOf(0, 2, 6, 8),
            intArrayOf(0, 2, 4, 6, 8),
            intArrayOf(0, 2, 3, 5, 6, 8)
        )
    }
}
