package com.example.ludogame.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.example.ludogame.R
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/** Banner flavours: a tall adaptive banner for roomy screens, or the compact 320x50 banner. */
enum class BannerStyle { LARGE_ADAPTIVE, COMPACT }

/**
 * Single place that owns every AdMob call in the app.
 *
 * WHERE ARE MY ADMOB IDS?
 * -----------------------
 * Not in this file. Put them in:  app/src/main/res/values/strings.xml
 *   admob_app_id, admob_banner_id, admob_interstitial_id, admob_rewarded_id
 * (admob_app_id is also read by AndroidManifest.xml.)
 *
 * The strings.xml values are Google's TEST IDs. Replace them with your real IDs before release.
 */
object AdManager {

    private const val TAG = "AdManager"

    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var appContext: Context
    private var started = false

    private var interstitialAd: InterstitialAd? = null
    private var interstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var rewardedLoading = false

    // ---------------------------------------------------------------- initialisation

    /** Call once from Application.onCreate(). Initialises the SDK off the main thread, then preloads ads. */
    fun initialize(context: Context) {
        if (started) return
        started = true
        appContext = context.applicationContext

        // OPTIONAL while testing on a real device: register your device as a test device.
        // Find the ID in Logcat (search for "Use RequestConfiguration.Builder().setTestDeviceIds").
        //
        // MobileAds.setRequestConfiguration(
        //     RequestConfiguration.Builder().setTestDeviceIds(listOf("YOUR_TEST_DEVICE_ID")).build()
        // )

        Thread {
            MobileAds.initialize(appContext) {
                // Ads must be loaded on the main thread.
                mainHandler.post {
                    loadInterstitial()
                    loadRewarded()
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- banner

    /** Creates a banner, puts it into [container] and destroys it automatically with the activity. */
    fun attachBanner(
        activity: AppCompatActivity,
        container: FrameLayout,
        style: BannerStyle = BannerStyle.LARGE_ADAPTIVE
    ) {
        val adView = AdView(activity)
        adView.adUnitId = activity.getString(R.string.admob_banner_id)
        adView.setAdSize(
            when (style) {
                BannerStyle.LARGE_ADAPTIVE ->
                    AdSize.getLargeAnchoredAdaptiveBannerAdSize(activity, screenWidthDp(activity))
                BannerStyle.COMPACT -> AdSize.BANNER
            }
        )

        container.removeAllViews()
        container.addView(
            adView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL
            )
        )
        adView.loadAd(AdRequest.Builder().build())

        activity.lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                (adView.parent as? ViewGroup)?.removeView(adView)
                adView.destroy()
            }
        })
    }

    private fun screenWidthDp(activity: Activity): Int {
        val metrics = activity.resources.displayMetrics
        return (metrics.widthPixels / metrics.density).toInt()
    }

    // ---------------------------------------------------------------- interstitial

    fun loadInterstitial() {
        if (interstitialAd != null || interstitialLoading) return
        interstitialLoading = true
        InterstitialAd.load(
            appContext,
            appContext.getString(R.string.admob_interstitial_id),
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    interstitialLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Interstitial failed to load: ${error.message}")
                    interstitialAd = null
                    interstitialLoading = false
                }
            }
        )
    }

    /**
     * Shows the interstitial if one is ready, then calls [onFinished].
     * If no ad is ready (offline, no fill), [onFinished] is called immediately so the game never gets stuck.
     */
    fun showInterstitial(activity: Activity, onFinished: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) {
            loadInterstitial()
            onFinished()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                loadInterstitial()
                onFinished()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.w(TAG, "Interstitial failed to show: ${error.message}")
                interstitialAd = null
                loadInterstitial()
                onFinished()
            }
        }
        ad.show(activity)
    }

    // ---------------------------------------------------------------- rewarded video

    fun loadRewarded() {
        if (rewardedAd != null || rewardedLoading) return
        rewardedLoading = true
        RewardedAd.load(
            appContext,
            appContext.getString(R.string.admob_rewarded_id),
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    rewardedLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Rewarded failed to load: ${error.message}")
                    rewardedAd = null
                    rewardedLoading = false
                }
            }
        )
    }

    /**
     * Shows a rewarded video if one is ready and returns true.
     * [onResult] is called when the video is closed, with `true` if the viewer earned the reward.
     * Returns false (and starts loading another video) when no video is ready.
     */
    fun showRewarded(activity: Activity, onResult: (earned: Boolean) -> Unit): Boolean {
        val ad = rewardedAd
        if (ad == null) {
            loadRewarded()
            return false
        }
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewarded()
                onResult(earned)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.w(TAG, "Rewarded failed to show: ${error.message}")
                rewardedAd = null
                loadRewarded()
                onResult(false)
            }
        }
        ad.show(activity) { earned = true }
        return true
    }
}
