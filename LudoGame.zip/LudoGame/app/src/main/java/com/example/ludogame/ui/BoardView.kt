package com.example.ludogame.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import com.example.ludogame.game.Board
import com.example.ludogame.game.GameEngine
import com.example.ludogame.game.PlayerColor
import com.example.ludogame.game.Pos
import com.example.ludogame.game.Token
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Draws the whole Ludo board with Canvas (no image files needed), the tokens, the pulsing highlight on
 * tokens that can move, and animates token movement cell by cell.
 */
class BoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /** The game being displayed. */
    var engine: GameEngine? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Tokens the player may tap right now (they get a pulsing ring). */
    var highlighted: List<Token> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    /** Called when the player taps one of the [highlighted] tokens. */
    var onTokenTapped: ((Token) -> Unit)? = null

    private var cell = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF90A4AE.toInt()
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val path = Path()

    // Move animation state
    private var animToken: Token? = null
    private var animPos: Pos? = null
    private var animHop = 0f
    private var moveAnimator: ValueAnimator? = null

    // Pulse for highlighted tokens
    private var pulse = 0f
    private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 800L
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener {
            pulse = it.animatedValue as Float
            if (highlighted.isNotEmpty()) invalidate()
        }
    }

    // ------------------------------------------------------------------ view plumbing

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cell = w / Board.GRID.toFloat()
        line.strokeWidth = max(1f, cell * 0.035f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        pulseAnimator.start()
    }

    override fun onDetachedFromWindow() {
        pulseAnimator.cancel()
        moveAnimator?.cancel()
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ touch

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (highlighted.isEmpty()) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val best = highlighted.minByOrNull { distanceTo(it, event.x, event.y) }
                if (best != null && distanceTo(best, event.x, event.y) <= cell) {
                    performClick()
                    onTokenTapped?.invoke(best)
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean = super.performClick()

    private fun distanceTo(token: Token, x: Float, y: Float): Float {
        val p = Board.position(token.color, token.index, token.progress)
        return hypot(p.x * cell - x, p.y * cell - y)
    }

    // ------------------------------------------------------------------ animation

    /**
     * Slides [token] along [path] (one point per cell) with a small hop per cell, then calls [onEnd].
     * The engine state is NOT changed here: call engine.applyMove() inside [onEnd].
     */
    fun animateMove(token: Token, path: List<Pos>, onEnd: () -> Unit) {
        moveAnimator?.cancel()
        val points = listOf(Board.position(token.color, token.index, token.progress)) + path
        val segments = points.size - 1
        if (segments <= 0) {
            onEnd()
            return
        }
        animToken = token
        val total = if (token.inBase) 450L else (170L * segments).coerceAtMost(1500L)
        val anim = ValueAnimator.ofFloat(0f, segments.toFloat())
        anim.duration = total
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener {
            val v = it.animatedValue as Float
            val i = v.toInt().coerceAtMost(segments - 1)
            val f = v - i
            val a = points[i]
            val b = points[i + 1]
            animPos = Pos(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
            animHop = sin(PI * f).toFloat() * 0.18f
            invalidate()
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false

            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                animToken = null
                animPos = null
                animHop = 0f
                invalidate()
                if (!cancelled) onEnd()
            }
        })
        moveAnimator = anim
        anim.start()
    }

    // ------------------------------------------------------------------ drawing

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (cell <= 0f) return
        fill.color = Color.WHITE
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
        drawBases(canvas)
        drawTrack(canvas)
        drawHomeColumns(canvas)
        drawCenter(canvas)
        drawTokens(canvas)
    }

    private fun isActive(color: PlayerColor): Boolean =
        engine?.players?.any { it.color == color } ?: true

    private fun drawBases(canvas: Canvas) {
        val currentColor = engine?.current?.color
        for (color in PlayerColor.values()) {
            val active = isActive(color)
            val main = if (active) color.main else INACTIVE
            val bx = color.baseCol * cell
            val by = color.baseRow * cell

            fill.color = main
            canvas.drawRect(bx, by, bx + 6 * cell, by + 6 * cell, fill)

            rect.set(bx + cell, by + cell, bx + 5 * cell, by + 5 * cell)
            fill.color = Color.WHITE
            canvas.drawRoundRect(rect, cell * 0.5f, cell * 0.5f, fill)

            for (i in 0..3) {
                val p = Board.basePos(color, i)
                fill.color = if (active) color.light else 0xFFEEEEEE.toInt()
                canvas.drawCircle(p.x * cell, p.y * cell, cell * 0.62f, fill)
                ring.color = main
                ring.strokeWidth = cell * 0.06f
                canvas.drawCircle(p.x * cell, p.y * cell, cell * 0.62f, ring)
            }

            // Thick frame around the base of the player whose turn it is.
            if (active && currentColor == color) {
                val w = cell * 0.18f
                ring.color = color.dark
                ring.strokeWidth = w
                rect.set(bx + w / 2, by + w / 2, bx + 6 * cell - w / 2, by + 6 * cell - w / 2)
                canvas.drawRect(rect, ring)
            }
        }
    }

    private fun drawTrack(canvas: Canvas) {
        for ((i, c) in Board.TRACK.withIndex()) {
            val startOwner = PlayerColor.values().firstOrNull { it.startIndex == i }
            fill.color = startOwner?.main ?: Color.WHITE
            rect.set(c.first * cell, c.second * cell, (c.first + 1) * cell, (c.second + 1) * cell)
            canvas.drawRect(rect, fill)
            canvas.drawRect(rect, line)

            if (i in Board.SAFE_INDEXES) {
                val starColor = if (startOwner != null) Color.WHITE else 0xFF78909C.toInt()
                drawStar(canvas, (c.first + 0.5f) * cell, (c.second + 0.5f) * cell, cell * 0.32f, starColor)
            }
        }
    }

    private fun drawHomeColumns(canvas: Canvas) {
        for (color in PlayerColor.values()) {
            for (c in Board.homeColumn(color)) {
                fill.color = color.main
                rect.set(c.first * cell, c.second * cell, (c.first + 1) * cell, (c.second + 1) * cell)
                canvas.drawRect(rect, fill)
                canvas.drawRect(rect, line)
            }
        }
    }

    private fun drawCenter(canvas: Canvas) {
        triangle(canvas, 6f, 6f, 6f, 9f, 7.5f, 7.5f, PlayerColor.RED.main)
        triangle(canvas, 6f, 6f, 9f, 6f, 7.5f, 7.5f, PlayerColor.GREEN.main)
        triangle(canvas, 9f, 6f, 9f, 9f, 7.5f, 7.5f, PlayerColor.YELLOW.main)
        triangle(canvas, 6f, 9f, 9f, 9f, 7.5f, 7.5f, PlayerColor.BLUE.main)
    }

    private fun triangle(
        canvas: Canvas,
        x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float,
        color: Int
    ) {
        path.reset()
        path.moveTo(x1 * cell, y1 * cell)
        path.lineTo(x2 * cell, y2 * cell)
        path.lineTo(x3 * cell, y3 * cell)
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
        canvas.drawPath(path, line)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, outer: Float, color: Int) {
        val inner = outer * 0.45f
        path.reset()
        for (k in 0 until 10) {
            val r = if (k % 2 == 0) outer else inner
            val angle = -PI / 2 + k * PI / 5
            val x = cx + (r * cos(angle)).toFloat()
            val y = cy + (r * sin(angle)).toFloat()
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = color
        canvas.drawPath(path, fill)
    }

    private fun drawTokens(canvas: Canvas) {
        val eng = engine ?: return
        val tokens = eng.players.flatMap { it.tokens }.filter { it !== animToken }
        val groups = tokens.groupBy { Board.position(it.color, it.index, it.progress) }

        for ((pos, group) in groups) {
            val n = group.size
            group.forEachIndexed { i, token ->
                val (dx, dy) = stackOffset(i, n)
                val radius = cell * if (token.finished) 0.2f else if (n == 1) 0.4f else 0.27f
                drawToken(
                    canvas,
                    (pos.x + dx) * cell,
                    (pos.y + dy) * cell,
                    radius,
                    token.color,
                    highlighted.contains(token)
                )
            }
        }

        val moving = animToken
        val where = animPos
        if (moving != null && where != null) {
            drawToken(canvas, where.x * cell, (where.y - animHop) * cell, cell * 0.44f, moving.color, false)
        }
    }

    /** Spreads several tokens that share one square so they stay visible. */
    private fun stackOffset(i: Int, n: Int): Pair<Float, Float> = when {
        n <= 1 -> 0f to 0f
        n == 2 -> (if (i == 0) -0.2f else 0.2f) to 0f
        n == 3 -> when (i) {
            0 -> -0.2f to -0.15f
            1 -> 0.2f to -0.15f
            else -> 0f to 0.2f
        }
        else -> (if (i % 2 == 0) -0.2f else 0.2f) to (if ((i / 2) % 2 == 0) -0.2f else 0.2f)
    }

    private fun drawToken(canvas: Canvas, cx: Float, cy: Float, r: Float, color: PlayerColor, glow: Boolean) {
        fill.color = 0x33000000
        canvas.drawCircle(cx + r * 0.08f, cy + r * 0.14f, r, fill)
        fill.color = color.dark
        canvas.drawCircle(cx, cy, r, fill)
        fill.color = color.main
        canvas.drawCircle(cx, cy, r * 0.78f, fill)
        fill.color = 0x66FFFFFF
        canvas.drawCircle(cx - r * 0.25f, cy - r * 0.25f, r * 0.25f, fill)
        if (glow) {
            ring.color = 0xFF212121.toInt()
            ring.strokeWidth = cell * 0.07f
            canvas.drawCircle(cx, cy, r * (1.2f + 0.25f * pulse), ring)
        }
    }

    private companion object {
        const val INACTIVE = 0xFFBDBDBD.toInt()
    }
}
