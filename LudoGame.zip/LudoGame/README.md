# Ludo Offline (Android, Kotlin) with Google AdMob

Offline Ludo for 2 to 4 players, drawn entirely with Canvas (no image assets), with a dice
animation, smooth token movement, a simple computer opponent, and AdMob ads.

## Open and run

1. Android Studio (latest stable) > **File > Open** > select the `LudoGame` folder.
2. Let Gradle sync (it downloads Gradle 8.9 automatically from `gradle/wrapper/gradle-wrapper.properties`).
3. Run on an emulator or a phone. Ads show Google **test ads** until you add your own IDs.

## Where to put YOUR AdMob IDs

Everything is in one file: `app/src/main/res/values/strings.xml`

| String name              | What it is                          | Looks like                        |
|--------------------------|-------------------------------------|-----------------------------------|
| `admob_app_id`           | AdMob **App ID** (used by manifest) | `ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY` |
| `admob_banner_id`        | Banner ad unit                      | `ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ` |
| `admob_interstitial_id`  | Interstitial ad unit                | same format as banner             |
| `admob_rewarded_id`      | Rewarded video ad unit              | same format as banner             |

The values currently in the file are Google's official **test IDs**. Replace all four before publishing.
Never click your own live ads.

Also change the package name `com.example.ludogame` (in `app/build.gradle.kts`, the Kotlin
package lines and the folders) to your own before you publish.

## Where each ad appears

| Ad            | Where                                              | Code                                      |
|---------------|----------------------------------------------------|-------------------------------------------|
| Banner        | Bottom of the menu and of the game screen          | `MainActivity`, `GameActivity` > `AdManager.attachBanner()` |
| Interstitial  | After every finished match (Play again / Menu)     | `GameActivity.onGameOver()` > `AdManager.showInterstitial()` |
| Rewarded      | Optional button "Watch a video for a Lucky 6"      | `GameActivity.onRewardClicked()` > `AdManager.showRewarded()` |

All AdMob code lives in `ads/AdManager.kt`. If an ad is not ready (offline or no fill) the game simply
continues, it never blocks.

## Project structure

```
app/src/main/java/com/example/ludogame/
  LudoApp.kt            starts the AdMob SDK
  MainActivity.kt       menu (2/3/4 players, vs computer switch)
  GameActivity.kt       turn flow, dice, moves, ads, win dialog
  ads/AdManager.kt      banner, interstitial, rewarded
  game/PlayerColor.kt   colours and seats
  game/Board.kt         board geometry (52-square track, home columns, safe squares)
  game/GameEngine.kt    pure rules + simple bot AI (no Android code)
  ui/BoardView.kt       Canvas board, tokens, highlight, move animation
  ui/DiceView.kt        Canvas dice with tumbling animation
```

## Rules implemented

- A 6 brings a token out of the base.
- A 6, a capture or reaching home gives another turn. Three sixes in a row forfeit the turn.
- Landing on an opponent captures it, except on start squares and star squares (safe).
- A token needs an exact roll to reach the centre.
- First player to bring all four tokens home wins.

## Before you publish

- Replace the test IDs, the package name and the placeholder icon (right-click `res` > New > Image Asset).
- If you have users in the EEA/UK, add Google's User Messaging Platform (UMP) consent form.
- If the game targets children, follow Google Play's Families policy and AdMob's child-directed settings.
- Google has put the Google Mobile Ads SDK in maintenance mode and recommends the newer GMA Next-Gen SDK;
  this project uses `play-services-ads` 25.5.0, which still works.
