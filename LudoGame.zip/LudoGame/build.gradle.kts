// Top-level build file.
// Google Mobile Ads SDK 25.x requires Kotlin 2.1.0 or newer.
// If Android Studio suggests newer plugin versions (AGP Upgrade Assistant), you can accept them.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.1.0" apply false
}
